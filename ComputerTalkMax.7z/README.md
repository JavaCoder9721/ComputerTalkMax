Welcome 
ComputerTalkMax is not a seperate repository (yes it is)
but ComputerTalkMax is made for more readable syntax than ComputerTalk

look at this program in ComputerTalkMax:
    read hello.
    This is just english 
look at this one here:
    word a, 40.
    read a
    Words are the variables in ComputerTalkMax
    and make sure to add a '.' at the end of a line!!
 
examples:
    writing:
        read hello.
    vars/word:
        word a, 391.
        read a.
    func/tense:
        tense sayHello,read hello!.
        use tense sayHello.


I hope you like ComputerTalkMax
please star it or give it a test
        
        