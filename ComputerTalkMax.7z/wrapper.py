import ComputerTalkMax

sys = ComputerTalkMax.ctmax()

file = open("script.ctm")

code = file.read()

sys.execute(code)

file.close()