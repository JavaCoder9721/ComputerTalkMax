class ctmax:
    def __init__(self):
        self.vars = {}
        self.tense = {}
    def execute(self,code):
        source = code.split("\n")
        for l in source:
            
            # printing #
            
            if l.startswith("read ") and l.endswith("."):
                text = l[5:].replace(".","")
                if text in self.vars:
                    print(self.vars[text])
                else:
                    print(l[5:].replace(".",""))
                
            # Variables #
            
            elif l.startswith("word ") and l.endswith("."):
                var = l.replace("word ","").replace(".","").split(", ")
                word_name = var[0]
                word_value = var[1]
                self.vars[word_name] = word_value
            
            # Functions/tenses #
            
            elif l.startswith("tense "):
                tense = l.replace("tense ","").split(",")
                name = tense[0]
                ts = tense[1]
                if ts.startswith("read ") and ts.endswith("."):
                    self.tense[name] = ts[5:].replace(".","")
                else:
                    print(f"Error occurred in tense {name}")
            elif l.startswith("use tense ") and l.endswith("."):
                t_name = l[10:].replace(".","")
                if t_name in self.tense:
                    print(self.tense[t_name])
                else:
                    print(f"Error occurred while using tense\nNo tenses for {t_name}")
            # Error #
            
            else:
                raise NameError(f"No phrases for {l}")